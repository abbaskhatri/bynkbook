# Bynkbook Copilot Instructions

Follow:
- docs/BYNKBOOK_CONSTITUTION_v1_1.md (locked v1.1)
- docs/UI_STANDARDS_PHASE3.md
- docs/PHASE3_UI_WORK_ORDER.md

Phase 3 rule: frontend-only changes unless the issue explicitly approves backend work.

All work must be Issue → PR → Review → Merge and include “How to verify” steps.
