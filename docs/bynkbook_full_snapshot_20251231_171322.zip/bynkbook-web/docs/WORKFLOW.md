Always work on main (dev only).

Never use GitHub Issues/PRs.

Use VS Code Copilot Chat to edit files.

Commit + Push after each small change.

If something breaks: Undo by “History → right click commit → Revert” in GitHub Desktop.