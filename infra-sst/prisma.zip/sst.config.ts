/// <reference path="./.sst/platform/config.d.ts" />

export default $config({
  app(input) {
    return {
      name: "ledrigo",
      home: "aws",
    };
  },

  async run() {
    const api = new sst.aws.ApiGatewayV2("ledrigo-dev-sst-api", {
      cors: {
        allowHeaders: ["authorization", "content-type"],
        allowMethods: ["GET", "POST", "DELETE", "PUT", "PATCH", "OPTIONS"],
        allowOrigins: ["http://localhost:3000"],
      },
    });

    const authorizer = api.addAuthorizer({
      name: "ledrigo-dev-cognito-jwt",
      jwt: {
        issuer: "https://cognito-idp.us-east-1.amazonaws.com/us-east-1_tmyPJwsJb",
        audiences: ["38gus49pnfilbc4u2f7b68ist7"],
        identitySource: "$request.header.Authorization",
      },
    });

    const RUNTIME = "nodejs22.x" as const;
    type ApiHandler = Parameters<typeof api.route>[1];

    // ========== Public Routes ==========
    api.route("GET /v1/health", {
      handler: "packages/functions/src/health.handler",
      runtime: RUNTIME,
      memory: "256 MB",
      timeout: "10 seconds",
    });

    // ========== Protected Routes ==========
    api.route(
      "GET /v1/me",
      {
        handler: "packages/functions/src/me.handler",
        runtime: RUNTIME,
        memory: "256 MB",
        timeout: "10 seconds",
      },
      { auth: { jwt: { authorizer: authorizer.id } } }
    );

    // ---------- Businesses ----------
    const bizHandler = {
      handler: "packages/functions/src/businesses.handler",
      runtime: RUNTIME,
      memory: "512 MB",
      timeout: "20 seconds",
      vpc: {
        securityGroups: ["sg-0fe7b2ad87e2b2bb8"],
        privateSubnets: ["subnet-016a9caf338ab17e3", "subnet-04ff62b426b19d70b"],
      },
      environment: {
        DB_URL_SECRET_ID: "ledrigo-dev/rds/database_url",
        NODE_TLS_REJECT_UNAUTHORIZED: "0",
        CACHE_BUSTER: "20251224095558",
      },
      permissions: [
        {
          actions: ["secretsmanager:GetSecretValue", "secretsmanager:DescribeSecret"],
          resources: [
            "arn:aws:secretsmanager:us-east-1:116846786465:secret:ledrigo-dev/rds/database_url-*",
          ],
        },
        {
          actions: ["kms:Decrypt"],
          resources: ["arn:aws:kms:us-east-1:116846786465:key/7f953e5a-b3c9-4354-9ba9-e4f980717c36"],
        },
      ],
    } satisfies ApiHandler;

    api.route("GET /v1/businesses", bizHandler, { auth: { jwt: { authorizer: authorizer.id } } });
    api.route("POST /v1/businesses", bizHandler, { auth: { jwt: { authorizer: authorizer.id } } });

    // ---------- Accounts ----------
    const acctHandler = {
      ...bizHandler,
      handler: "packages/functions/src/accounts.handler",
    } satisfies ApiHandler;

    api.route("GET /v1/businesses/{businessId}/accounts", acctHandler, { auth: { jwt: { authorizer: authorizer.id } } });
    api.route("POST /v1/businesses/{businessId}/accounts", acctHandler, { auth: { jwt: { authorizer: authorizer.id } } });

    // ---------- Uploads (Phase 4A-2 + 4A-3) ----------
    const uploadsHandler = {
      ...bizHandler,
      handler: "packages/functions/src/uploads.handler",
      environment: {
        ...bizHandler.environment,
        UPLOADS_BUCKET_NAME: "ledrigo-dev-uploads-116846786465-us-east-1",
      },
      permissions: [
        ...(bizHandler as any).permissions,

        // S3 least-privilege: only our uploads prefix
        {
          actions: ["s3:PutObject", "s3:GetObject"],
          resources: ["arn:aws:s3:::ledrigo-dev-uploads-116846786465-us-east-1/private/biz/*"],
        },

        // KMS scoped to key ARN (SSE-KMS)
        {
          actions: ["kms:Encrypt", "kms:GenerateDataKey", "kms:DescribeKey", "kms:Decrypt"],
          resources: ["arn:aws:kms:us-east-1:116846786465:key/7f953e5a-b3c9-4354-9ba9-e4f980717c36"],
        },
      ],
    } satisfies ApiHandler;

    api.route("POST /v1/businesses/{businessId}/uploads/init", uploadsHandler, { auth: { jwt: { authorizer: authorizer.id } } });
    api.route("POST /v1/businesses/{businessId}/uploads/mark-uploaded", uploadsHandler, {
  auth: { jwt: { authorizer: authorizer.id } },
});
    api.route("POST /v1/businesses/{businessId}/uploads/complete", uploadsHandler, { auth: { jwt: { authorizer: authorizer.id } } });
    api.route("GET /v1/businesses/{businessId}/uploads", uploadsHandler, { auth: { jwt: { authorizer: authorizer.id } } });
    api.route("GET /v1/businesses/{businessId}/uploads/{uploadId}/download", uploadsHandler, { auth: { jwt: { authorizer: authorizer.id } } });

// ---------- Plaid (Phase 4B: connect + sync only) ----------
const plaidHandler = {
  ...bizHandler,
  handler: "packages/functions/src/plaidLinkToken.handler",
  environment: {
    ...bizHandler.environment,
    PLAID_ENV: "sandbox",
    PLAID_CLIENT_ID_SECRET_ID: "ledrigo-dev/plaid/client_id",
    PLAID_SECRET_SECRET_ID: "ledrigo-dev/plaid/secret",
    PLAID_TOKEN_KMS_KEY_ID: "alias/ledrigo-dev-app",
  },
  permissions: [
    ...(bizHandler as any).permissions,

    // Read Plaid creds from Secrets Manager (IDs/names referenced above)
    {
      actions: ["secretsmanager:GetSecretValue", "secretsmanager:DescribeSecret"],
      resources: ["*"],
    },

    // Encrypt/decrypt Plaid access tokens
    {
      actions: ["kms:Encrypt", "kms:Decrypt", "kms:GenerateDataKey", "kms:DescribeKey"],
      resources: ["*"],
    },
  ],
} satisfies ApiHandler;

const plaidLinkTokenHandler = {
  ...plaidHandler,
  handler: "packages/functions/src/plaidLinkToken.handler",
} satisfies ApiHandler;

const plaidExchangeHandler = {
  ...plaidHandler,
  handler: "packages/functions/src/plaidExchange.handler",
} satisfies ApiHandler;

const plaidStatusHandler = {
  ...plaidHandler,
  handler: "packages/functions/src/plaidStatus.handler",
} satisfies ApiHandler;

const plaidSyncHandler = {
  ...plaidHandler,
  handler: "packages/functions/src/plaidSync.handler",
  timeout: "45 seconds",
} satisfies ApiHandler;

// Protected Plaid routes (Cognito)
api.route(
  "POST /v1/businesses/{businessId}/accounts/{accountId}/plaid/link-token",
  plaidLinkTokenHandler,
  { auth: { jwt: { authorizer: authorizer.id } } }
);

api.route(
  "POST /v1/businesses/{businessId}/accounts/{accountId}/plaid/exchange",
  plaidExchangeHandler,
  { auth: { jwt: { authorizer: authorizer.id } } }
);

api.route(
  "GET /v1/businesses/{businessId}/accounts/{accountId}/plaid/status",
  plaidStatusHandler,
  { auth: { jwt: { authorizer: authorizer.id } } }
);

api.route(
  "POST /v1/businesses/{businessId}/accounts/{accountId}/plaid/sync",
  plaidSyncHandler,
  { auth: { jwt: { authorizer: authorizer.id } } }
);

// Public webhook (no Cognito auth)
const plaidWebhookHandler = {
  ...bizHandler,
  handler: "packages/functions/src/plaidWebhook.handler",
  environment: {
    ...bizHandler.environment,
    PLAID_ENV: "sandbox",
  },
} satisfies ApiHandler;

api.route("POST /v1/plaid/webhook", plaidWebhookHandler);

    // ---------- Entries ----------
    const entryHandler = {
      ...bizHandler,
      handler: "packages/functions/src/entries.handler",
    } satisfies ApiHandler;

    api.route("GET /v1/businesses/{businessId}/accounts/{accountId}/entries", entryHandler, { auth: { jwt: { authorizer: authorizer.id } } });
    api.route("POST /v1/businesses/{businessId}/accounts/{accountId}/entries", entryHandler, { auth: { jwt: { authorizer: authorizer.id } } });
    api.route("DELETE /v1/businesses/{businessId}/accounts/{accountId}/entries/{entryId}", entryHandler, { auth: { jwt: { authorizer: authorizer.id } } });
    api.route("POST /v1/businesses/{businessId}/accounts/{accountId}/entries/{entryId}/restore", entryHandler, { auth: { jwt: { authorizer: authorizer.id } } });

    // ---------- Issues Scan ----------
    const issuesScanHandler = {
      handler: "packages/functions/src/issuesScan.handler",
      runtime: RUNTIME,
      memory: "512 MB",
      timeout: "20 seconds",
      vpc: {
        securityGroups: ["sg-0fe7b2ad87e2b2bb8"],
        privateSubnets: ["subnet-016a9caf338ab17e3", "subnet-04ff62b426b19d70b"],
      },
      environment: {
        DB_URL_SECRET_ID: "ledrigo-dev/rds/database_url",
        NODE_TLS_REJECT_UNAUTHORIZED: "0",
        CACHE_BUSTER: "202601030001",
      },
      permissions: [
        {
          actions: ["secretsmanager:GetSecretValue", "secretsmanager:DescribeSecret"],
          resources: [
            "arn:aws:secretsmanager:us-east-1:116846786465:secret:ledrigo-dev/rds/database_url-*",
          ],
        },
        {
          actions: ["kms:Decrypt"],
          resources: ["arn:aws:kms:us-east-1:116846786465:key/7f953e5a-b3c9-4354-9ba9-e4f980717c36"],
        },
      ],
    } satisfies ApiHandler;

    api.route("POST /v1/businesses/{businessId}/accounts/{accountId}/issues/scan", issuesScanHandler, { auth: { jwt: { authorizer: authorizer.id } } });

    // ---------- Issues List ----------
    const issuesListHandler = {
      ...issuesScanHandler,
      handler: "packages/functions/src/issuesList.handler",
    } satisfies ApiHandler;

    api.route("GET /v1/businesses/{businessId}/accounts/{accountId}/issues", issuesListHandler, { auth: { jwt: { authorizer: authorizer.id } } });

    // ---------- Entry Update ----------
    const entryUpdateHandler = {
      ...entryHandler,
      handler: "packages/functions/src/entryUpdate.handler",
    } satisfies ApiHandler;

    api.route("PUT /v1/businesses/{businessId}/accounts/{accountId}/entries/{entryId}", entryUpdateHandler, { auth: { jwt: { authorizer: authorizer.id } } });
    api.route("PATCH /v1/businesses/{businessId}/accounts/{accountId}/entries/{entryId}", entryUpdateHandler, { auth: { jwt: { authorizer: authorizer.id } } });

    // ---------- Entry Hard Delete ----------
    const entryHardDeleteHandler = {
      ...entryHandler,
      handler: "packages/functions/src/entryHardDelete.handler",
    } satisfies ApiHandler;

    api.route("DELETE /v1/businesses/{businessId}/accounts/{accountId}/entries/{entryId}/hard", entryHardDeleteHandler, { auth: { jwt: { authorizer: authorizer.id } } });

    // ---------- Ledger Summary ----------
    const ledgerSummaryHandler = {
      ...bizHandler,
      handler: "packages/functions/src/ledgerSummary.handler",
    } satisfies ApiHandler;

    api.route("GET /v1/businesses/{businessId}/accounts/{accountId}/ledger-summary", ledgerSummaryHandler, { auth: { jwt: { authorizer: authorizer.id } } });

    return { apiUrl: api.url };
  },
});
